KinectWindowsInteraction
========================

This project seeks to integrate the kinect with windows to allow people with disabilities to still operate a computer.
