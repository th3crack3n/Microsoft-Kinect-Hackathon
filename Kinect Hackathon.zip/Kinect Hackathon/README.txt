 _   ___                                 _   
| | / (_)                               | |  
| |/ / _ _ __  _ __   ___ _ __ __ _  ___| |_ 
|    \| | '_ \| '_ \ / _ \ '__/ _` |/ __| __|
| |\  \ | | | | | | |  __/ | | (_| | (__| |_ 
\_| \_/_|_| |_|_| |_|\___|_|  \__,_|\___|\__|
                                             
        
-------------
Team : Finger Puppet Mafia
Members : Sean McCracken, Geoffrey Miller, Ryan Wade
Project : Simple operating system interaction via hand gestures and voice



Gestures Guide:
	- Mouse : Start with right arm near head


Voice Command List :
	- "Kinect to Internet" : open internet explorer
	- "Kinect to Chrome" : open google chrome
	- "Kinect to Facebook" : open www.facebook.com in default browser
	- "Kinect to Google" : open www.google.com in default browser
	- "Kinect to Iowa State" : open www.iastate.edu in default browser
	- "Kinect to Command Prompt" : open new Command Prompt window at C:\ directory
	- "Kinect to Notepad" : open new Notepad window
	- "Left Click" : left click on current cursor position
	- "Right Click" : right click on current cursor position
	- "Double Click" : double click on current cursor position
	- "Grab" : hold window from current cursor position
	- "Release" : release currently grabbed window
	